#!/bin/sh
set -e

echo "Build"
sudo docker-compose -f deployment/compose/prod.yaml build

echo "Check"
grype localhost:5000/pice_distributor_website:v1.0.0

echo "Push"
sudo docker-compose -f deployment/compose/prod.yaml push

# echo "Remove existing service"
# sudo docker stack rm pice_distributor_website

echo "Deploy new build"
sudo docker stack deploy --compose-file deployment/compose/prod.yaml pice_distributor_website

echo "Cleanup"
sudo docker system prune

