/** @type {import('tailwindcss').Config} */
export default {
	content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
	theme: {
		container: {
			center: true,
			padding: "2rem",
		},
		extend: {
			colors: {
				primary: {
					100: "#081E4A",
					200: "#1D3A73",
					300: "#1D3A73",
					400: "#245CCB",
					500: "#92AEE5",
					600: "#C6D9FF",
					700: "#ECF1FF",
					800: "#F4F4F4",
					900: "#ECF2FD",
				},
				black: {
					100: "#0A0A0A",
					200: "#767676",
				},
				success: {
					100: "#007D36",
					200: "#4DA472",
				},
				error: {
					100: "#BD1C22",
					200: "#BD5758",
				},
			},

			backgroundImage: {
				"hero-bg": "url('/src/assets/main-bg.svg')",
			},
			fontFamily: {
				poppins: ["Poppins", "sans-serif"],
			},
		},
	},
	plugins: [],
};
