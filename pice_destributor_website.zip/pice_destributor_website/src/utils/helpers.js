export function addQueryParams(urlString, queryParams) {
	const query = Object.keys(queryParams)
		.map((k) => {
			if (Array.isArray(queryParams[k])) {
				return queryParams[k].map((val) => `${k}[]=${val}`).join("&");
			}
			return `${k}=${queryParams[k]}`;
		})
		.join("&");
	return `${urlString}?${query}`;
}

function getUrl() {
	let env = process.env.REACT_APP_NODE_ENV;
	if (env === "prod") return "https://pre-distributor.pice.one";
	else {
		return "https://pre-distributor.pice.one";
	}
}

export const BASE_IMG_URL = getUrl();
