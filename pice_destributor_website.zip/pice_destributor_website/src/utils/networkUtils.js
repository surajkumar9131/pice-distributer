import axios from "axios";
import { TOKEN_TYPE } from "./constants";

export const addBody = (body) => {
	let env = process.env.REACT_APP_NODE_ENV;

	if (env === "prod") {
		return {
			...body,
		};
	} else {
		return {
			...body,
		};
	}
};

const getAuth = () => localStorage.getItem(TOKEN_TYPE);

export function request(
	method,
	url,
	data,
	authorized = false,
	contentType = "application/json"
) {
	return new Promise((resolve, reject) => {
		const headers = {
			"Content-Type": contentType,
		};
		if (authorized) {
			headers[""] = `${getAuth()}`;
		}
		axios({
			method,
			url,
			data,
			headers,
			responseType: "text/json",
		})
			.then((res) => {
				resolve(res);
			})
			.catch((err) => {
				if (err.response.status === 401) {
					localStorage.removeItem(TOKEN_TYPE);
					// window.location.href = '/auth/login';
				}
				reject(err);
			});
	});
}

export const getErrorBody = (error) => {
	let response = {};
	try {
		response = error.response;
	} catch (err) {
		response = {};
	}
	response = response || {};
	const outputErrorBody = {
		...response.data,
		status: response.status ? response.status : 408,
	};
	return outputErrorBody;
};

const get_base_api = () => {
	let env = process.env.REACT_APP_NODE_ENV;

	if (env === "prod") return "";
	else {
		return "";
	}
};

export function addQueryParams(urlString, queryParams) {
	const query = Object.keys(queryParams)
		.map((k) => {
			if (Array.isArray(queryParams[k])) {
				return queryParams[k].map((val) => `${k}=${val}`).join("&");
			}
			return `${k}=${queryParams[k]}`;
		})
		.join("&");
	return `${urlString}?${query}`;
}

export const BASE_API = get_base_api();

export const getUrl = (relUrl) => `${BASE_API}/${relUrl}`;
