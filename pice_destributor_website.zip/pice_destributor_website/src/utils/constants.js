export const TOKEN_TYPE = "X-Pice-Session-Id";
