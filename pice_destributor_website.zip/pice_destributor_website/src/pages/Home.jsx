import BuiltFor from "../components/BuiltFor";
import CreatedBy from "../components/CreatedBy";
import Bg from "../assets/main-bg.svg";
import Phone from "../assets/phone.svg";
import Ic1 from "../assets/ic1.svg";
import Ic2 from "../assets/ic2.svg";
import Ic3 from "../assets/ic3.svg";
import DetailsForm from "../components/DetailsForm";
import { useState, useEffect, useMemo } from "react";
import { getUrl, request } from "../utils/networkUtils";
import { useMutation } from "react-query";
import { useLocation } from "react-router-dom";
import wpShare from "../assets/wpshare.svg";

function useQuery() {
	const { search } = useLocation();
	return useMemo(() => new URLSearchParams(search), [search]);
}

const Home = () => {
	let query = useQuery();
	const [details, setDetails] = useState(false);
	const generateHealthURL = () => {
		const url = getUrl(`communication`);
		return request("GET", url, null, true);
	};

	const gstNo = query.get("gst") ? query.get("gst").toUpperCase() : null;
	// eslint-disable-next-line no-unused-vars
	const { mutate: generateHealth, isLoading: generateHealthLoading } =
		useMutation(generateHealthURL, {
			onSuccess: (res) => {
				if (res.status === 204) {
					console.log(res);
				} else if (res.status === 200) {
					console.log(res);
				}
			},
			onError: (err) => console.log(err),
		});

	useEffect(() => {
		generateHealth();
	}, [generateHealth]);

	const chatOnWp = () => {
		window.location.href = "https://wa.me/918123475591?";
	};

	const [visible, setVisible] = useState(false);

	const toggleVisible = () => {
		const scrolled = document.documentElement.scrollTop;
		if (scrolled > 300) {
			setVisible(true);
		} else if (scrolled <= 300) {
			setVisible(false);
		}
	};

	window.addEventListener("scroll", toggleVisible);

	return (
		<>
			<div>
				<div className="bg-gradient-to-b from-white from-0% to-[#E9EFFD] to-100%">
					<div
						style={{ backgroundImage: `url(${Bg})` }}
						className="hero-bg bg-no-repeat px-6 lg:px-32 relative bg-contain lg:bg-auto bg-bottom lg:bg-left-bottom"
					>
						<div className="flex justify-between">
							<div className="mt-16 lg:mt-28">
								<div className="z-100">
									<div className="text-h3">Grow your Business</div>
									<div className="text-h2">Extend Credit line to your</div>
									<div className="text-h2">Customers upto</div>
									<div className="text-h1 text-transparent bg-clip-text bg-gradient-to-b from-[#0344AF] from-0% to-[#007CEF] to-100%">
										₹1 Cr at Zero Cost
									</div>
								</div>
								<div className="block lg:hidden mt-6">
									<button
										className="btn-primary"
										onClick={() => setDetails(true)}
									>
										Extend Credit Line
									</button>
								</div>

								<div className="mt-12 lg:mt-16">
									<img src={Phone} />
								</div>
							</div>

							<div className="hidden lg:block mt-4 mb-8 w-[30rem]">
								<DetailsForm showTag={details} gstNo={gstNo} />
							</div>
							{details && (
								<div className="block lg:hidden mt-6 bg-white w-[100%] fixed left-0 top-8 h-[100vh] z-100">
									<DetailsForm showTag={details} gstNo={gstNo} />
								</div>
							)}
						</div>
					</div>
				</div>
				<div className="bg-gradient-to-b from-[#7C9BFF] from-0% to-[#517AFF] to-100% text-white px-4 lg:px-32 py-10">
					<div className="flex flex-col justify-between lg:flex-row gap-4 text-sm lg:text-base">
						<div className="flex gap-2 items-center">
							<img src={Ic1} /> Receive payments from customers instantly
						</div>
						<div className="flex gap-2 items-center">
							<img src={Ic3} />
							Extend trade credit upto 45 days
						</div>
						<div className="flex gap-2 items-center">
							<img src={Ic2} />
							Increase working capital by 50%
						</div>
					</div>
				</div>
			</div>
			<BuiltFor />
			<div className="block lg:hidden">
				<div className="bg-[#D3E1FF] rounded-3xl px-4 py-4 flex-between mx-4 mb-4">
					<div className="text-[#4B6CB4] text-xs font-normal">
						<p>Are you a CA/Accountant ? </p>
						<p>Earn upto ₹50,000</p>
					</div>
					<div onClick={chatOnWp}>
						<img src={wpShare} />
					</div>
				</div>
			</div>
			<CreatedBy />
			{visible && !details && (
				<div className="block lg:hidden mt-6 fixed bottom-0 w-full">
					<button
						className="btn-primary !rounded-none"
						onClick={() => setDetails(true)}
					>
						Extend Credit Line
					</button>
				</div>
			)}
		</>
	);
};

export default Home;
