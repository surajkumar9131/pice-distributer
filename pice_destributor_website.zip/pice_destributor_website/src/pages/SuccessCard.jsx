/* eslint-disable no-unused-vars */
import { useState, useEffect } from "react";
import Confetti from "../assets/confetti.svg";
import Copy from "../assets/copy.svg";
import Customers from "../assets/customers.svg";
import Ic1 from "../assets/ic1.svg";
import Ic2 from "../assets/ic2.svg";
import Ic3 from "../assets/ic3.svg";
import Ic4 from "../assets/ic4.svg";
import Wps from "../assets/whatsapp.svg";
import Mail from "../assets/mail.svg";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { useNavigate, useLocation } from "react-router-dom";

const SuccessCard = () => {
	const [copied, setCopied] = useState(false);
	const location = useLocation();
	const data = location.state;
	console.log(data);

	const chatOnWp = () => {
		window.location.href = data?.communication?.finalPage;
	};

	useEffect(() => {
		if (copied) {
			setTimeout(() => {
				setCopied(false);
			}, 500);
		}
	}, [copied]);

	return (
		<div className="bg-gradient-to-b from-white from-0% to-[#E9EFFD] to-100%">
			<div
				style={{ backgroundImage: `url(${Confetti})` }}
				className="hero-bg bg-no-repeat"
			>
				<div className="bg-white rounded-3xl py-10 w-full lg:w-[40rem] m-auto text-center my-10">
					<div className="text-3xl font-medium text-[#007D36]">
						Congratulations!
					</div>
					<div className="py-4 lg:py-8 flex items-center justify-center">
						<img src={Customers} />
					</div>

					<div className="text-lg lg:text-2xl font-normal px-4 lg:px-44">
						Credit Line extended to 200 customers
					</div>
					<div className="bg-gradient-to-b from-[#7C9BFF] from-0% to-[#517AFF] to-100% text-white px-4 lg:px-24 py-10 my-8">
						<div className="flex flex-col gap-4 text-xs lg:text-base">
							<div className="flex gap-1 lg:gap-2 items-center">
								<img src={Ic1} /> Receive payments from customers instantly
							</div>
							<div className="flex gap-1 lg:gap-2 items-center">
								<img src={Ic3} />
								Extend trade credit upto 45 days
							</div>
							<div className="flex gap-1 lg:gap-2 items-center">
								<img src={Ic2} />
								Increase working capital by 50%
							</div>
						</div>
					</div>
					<div className="text-lg lg:text-xl font-normal">
						Share with your Customers
					</div>

					<CopyToClipboard
						text={data?.distributor?.referralLink}
						onCopy={() => setCopied(true)}
					>
						<div className="bg-[#F3F3F3] rounded-2xl flex-between text-sm lg:text-xl px-4 lg:px-6 py-2 lg:py-6 m-auto mt-8 mx-4 lg:mx-10">
							<span className="w-10/12 overflow-clip">
								{data?.distributor?.referralLink}
							</span>
							<img src={Copy} />
						</div>
					</CopyToClipboard>
					{copied && <span className="text-success-200 text-xs">Copied</span>}
					<div className="block lg:hidden" onClick={chatOnWp}>
						<div className="bg-primary-200 rounded-3xl flex items-center gap-2 text-white justify-center text-sm lg:text-xl px-4 lg:px-6 py-2 lg:py-6 m-auto mt-4 lg:mt-8 mx-4 lg:mx-10">
							<img src={Wps} />
							<span>Share Now</span>
						</div>
					</div>
				</div>
				<div className="text-center bg-white py-12">
					<div className="flex items-center justify-center">
						<img src={Ic4} />
					</div>
					<div className="text-lg lg:text-2xl font-normal mb-4 lg:mb-8">
						Contact Us
					</div>
					<div
						className="btn-lg-outline flex gap-1 lg:gap-2 items-center justify-center w-2/3 lg:w-1/6 m-auto mb-4 lg:mb-8"
						onClick={chatOnWp}
					>
						<img src={Wps} />
						<span>WhatsApp US</span>
					</div>
					<div className="flex gap-2 items-center justify-center text-sm lg:text-xl">
						<img src={Mail} />
						<span>
							Email: <span className="text-primary-200">hello@pice.one</span>
						</span>
					</div>
				</div>
			</div>
		</div>
	);
};

export default SuccessCard;
