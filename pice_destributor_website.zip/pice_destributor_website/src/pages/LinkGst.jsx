import Input from "../components/Input";
import { useState } from "react";
import OtpInput from "react-otp-input";
import { useNavigate, useLocation } from "react-router-dom";
import { addBody, request, getUrl } from "../utils/networkUtils";
import { useMutation } from "react-query";
import { TOKEN_TYPE } from "../utils/constants";
import ErrrorText from "../components/ErrrorText";
import Wps from "../assets/whatsapp.svg";
import Gs from "../assets/gs.svg";
import Qn from "../assets/qn.svg";
import GstSafe from "../assets/gstsafe.svg";
import DownArr from "../assets/downArrow.svg";
import Show from "../assets/show.svg";
import Hide from "../assets/hide.svg";

const LinkGst = () => {
	const navigate = useNavigate();
	const location = useLocation();
	const data = location.state;

	const [otp, setOtp] = useState("");
	const [otpSent, setOtpSent] = useState(false);
	const [showPass, setShowPass] = useState(false);
	const [username, setUsername] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState(null);

	const [selected, setSelected] = useState(false);

	const distributorConnect = (data) => {
		const url = getUrl(`distributor/connect`);
		return request("POST", url, addBody(data), true);
	};

	const verifyOtp = (data) => {
		const url = getUrl(`distributor/connect/otp`);
		return request("POST", url, addBody(data), true);
	};

	const { mutate: getOtp, isLoading: gstLoading } = useMutation(
		distributorConnect,
		{
			mutationKey: "distributor/connect",
			onSuccess: (res) => {
				if (res.status === 204 || res.status === 200) {
					let response = JSON.parse(res.data);
					console.log(response);
					setOtpSent(true);
				}
			},
			onError: (err) => {
				if (err.response.status === 400) {
					const error = JSON.parse(err.response.data);
					setError(error?.meta?.message);
					console.log(error);
				} else {
					setError("Something Went Wrong");
				}
				console.log(err);
			},
		}
	);

	const { mutate: otpVerify, isLoading: verifyOtpLoading } = useMutation(
		verifyOtp,
		{
			mutationKey: "distributor/connect/verify",
			onSuccess: (res) => {
				if (res.status === 204 || res.status === 200) {
					let response = JSON.parse(res.data);
					localStorage.removeItem(TOKEN_TYPE);
					navigate("/success", { state: response?.data });
				}
			},
			onError: (err) => {
				if (err.response.status === 400) {
					const error = JSON.parse(err.response.data);
					setError(error?.meta?.message);
					console.log(error);
				} else {
					setError("Something Went Wrong");
				}
				console.log(err);
			},
		}
	);

	const sendOtpHandler = () => {
		setError(null);
		if (username && password) {
			getOtp({
				username,
				password,
			});
		}
	};

	const verifyOtphandler = () => {
		if (otp.length) {
			otpVerify({
				otp,
			});
		}
	};

	const chatOnWp = () => {
		window.location.href = data?.communication?.enablePage;
	};

	return (
		<div>
			<div className="bg-gradient-to-b from-white from-0% to-[#E9EFFD] to-100% px-4 lg:px-32 py-8 lg:py-16 ">
				<div className="bg-white rounded-3xl py-10 px-4 lg:px-16 relative">
					<div className="hidden lg:block">
						<div className="flex justify-center absolute top-0 left-0 w-full">
							<img src={GstSafe} />
						</div>
					</div>
					<div className="w-full lg:w-1/2 m-auto mt-0 lg:mt-12">
						{!otpSent ? (
							<div>
								<div className="text-lg lg:text-2xl font-semibold">
									Link GST to make all your customers pre eligible
								</div>
								<div className="text-black-200 text-sm mt-3">
									Login with GST username and password
								</div>
								<div className="mt-6">
									<Input
										label={"GST Username *"}
										placeholder={"Enter Username"}
										required={true}
										value={username}
										onChange={(e) => setUsername(e.target.value)}
									/>
								</div>
								<div className="mt-6 relative">
									<Input
										label={"GST Password *"}
										placeholder={"Enter Password "}
										required={true}
										value={password}
										type={!showPass ? "password" : "text"}
										onChange={(e) => setPassword(e.target.value)}
									/>
									<div
										className="absolute right-5 bottom-[18px] cursor-pointer"
										onClick={() => setShowPass(!showPass)}
									>
										<img src={!showPass ? Show : Hide} />
									</div>
								</div>
								<div className="wrapper">
									<div className="bg-[#D3E1FF] rounded-xl px-3 py-3 mt-5">
										<div
											className="title"
											onClick={() => setSelected(!selected)}
										>
											<div className="text-xs font-normal flex gap-2">
												<img src={Qn} />
												<p>Why should I provide my GST Details?</p>
											</div>
											<span>
												<img src={DownArr} alt="arr" />
											</span>
										</div>
										<div className={selected ? "content show " : "content"}>
											<div className="text-xs font-normal my-4">
												Linking your GST with Pice will allow us to assess the
												credit worthiness of your customers and make them
												pre-eligible for credit.
											</div>
											<div className="text-[#007D36] text-xs font-normal flex gap-2">
												<img src={Gs} />
												<p>We do not store your GST Details</p>
											</div>
										</div>
									</div>
								</div>
								<div className="my-8">
									<button
										className={`${
											username.length >= 4 && password.length >= 4
												? "btn-primary"
												: "btn-dissabled"
										}  btn-primary`}
										onClick={sendOtpHandler}
									>
										<div className="flex items-center gap-1 justify-center">
											{gstLoading && <div className="loader"></div>}
											Link Securely
										</div>
									</button>
									{error && <ErrrorText text={error} />}
								</div>
								<div
									className="btn-lg-outline flex gap-1 lg:gap-2 items-center justify-center w-32 m-auto mb-4 lg:mb-8"
									onClick={chatOnWp}
								>
									<img src={Wps} />
									<span>Support</span>
								</div>
							</div>
						) : (
							<div className="text-center">
								<div className="text-black-200 mt-3">
									Enter 6 Digit OTP sent to your registered mobile number
								</div>
								{/* <div className="text-lg lg:text-2xl font-semibold">
									+913333333333
								</div> */}
								<div className="w-full lg:w-1/2 m-auto my-20">
									<OtpInput
										value={otp}
										onChange={setOtp}
										inputStyle="inputStyle"
										numInputs={6}
										separator={<span></span>}
										renderInput={(props) => <input {...props} />}
									/>
								</div>
								<div className="text-black-200 text-sm mt-3">
									Haven’t Received OTP?{" "}
									<span
										className="text-primary-200 underline cursor-pointer"
										onClick={sendOtpHandler}
									>
										Resend OTP
									</span>
								</div>
								<div className="my-8">
									<button
										className={`${
											otp.length === 6 ? "btn-primary" : "btn-dissabled"
										}  btn-primary`}
										onClick={verifyOtphandler}
									>
										<div className="flex items-center gap-1 justify-center">
											{verifyOtpLoading && <div className="loader"></div>}
											Confirm OTP
										</div>
									</button>
									{error && <ErrrorText text={error} />}
								</div>
							</div>
						)}
					</div>
				</div>
			</div>
		</div>
	);
};

export default LinkGst;
