import Confetti from "../assets/confetti.svg";
import ConIc from "../assets/conIc.svg";
import Watch from "../assets/stopwatch.svg";
import { useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";

const SecureOfferCard = () => {
	const location = useLocation();
	const data = location.state;
	const navigate = useNavigate();

	const [countDown, setCountDown] = useState(0);
	const [runTimer, setRunTimer] = useState(true);

	useEffect(() => {
		let timerId;

		if (runTimer) {
			setCountDown(60 * 5);
			timerId = setInterval(() => {
				setCountDown((countDown) => countDown - 1);
			}, 1000);
		} else {
			clearInterval(timerId);
		}

		return () => clearInterval(timerId);
	}, [runTimer]);

	useEffect(() => {
		if (countDown < 0 && runTimer) {
			setRunTimer(false);
			setCountDown(0);
		}
	}, [countDown, runTimer]);

	const seconds = String(countDown % 60).padStart(2, 0);
	const minutes = String(Math.floor(countDown / 60)).padStart(2, 0);

	const offerHandler = () => {
		setRunTimer(false);
		navigate("/link-gst", { state: data });
	};
	const numDifferentiation = (val) => {
		if (val >= 10000000) {
			val = val / 10000000 + " Crores";
		} else if (val >= 100000) {
			val = val / 100000 + " Lakhs";
		} else if (val >= 1000) val = val / 1000 + " K";
		return val;
	};

	return (
		<div className="bg-gradient-to-b from-white from-0% to-[#E9EFFD] to-100%">
			<div
				style={{ backgroundImage: `url(${Confetti})` }}
				className="hero-bg bg-no-repeat px-4 lg:px-32 py-10"
			>
				<div className="bg-white rounded-3xl py-8 lg:py-10 px-4 lg:px-12 w-full lg:w-[30rem] m-auto text-center">
					<div className="text-3xl font-medium text-[#007D36] text-center">
						Congratulations!
					</div>
					<div className="py-4 flex items-center justify-center">
						<img src={ConIc} />
					</div>
					<div className="text-3xl font-medium mb-2">
						{data?.distributor?.name}
					</div>
					<div className="ttext-lg lg:text-2xl font-normal ">
						You are eligible to extend credit line to customers up-to
					</div>
					<div className="text-h1 py-4">
						₹ {numDifferentiation(data?.distributor?.turnOver / 100)}
					</div>
					<button className="btn-primary" onClick={offerHandler}>
						Secure Offer
					</button>
					<div className="bg-[#F3F3F3] rounded-2xl flex-between text-sm w-36 p-1 m-auto mt-8">
						<img src={Watch} />
						<span>
							Expires in {minutes}:{seconds}
						</span>
					</div>
				</div>
			</div>
		</div>
	);
};

export default SecureOfferCard;
