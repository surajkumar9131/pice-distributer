import Certified from "../assets/certified.svg";

const CreatedBy = () => {
	return (
		<div className="fold shadow bg-primary-800">
			<div className="text-black-200 text-center text-xs font-normal mb-7">
				Certified By
			</div>
			<div>
				<img src={Certified} alt="cert" />
			</div>
		</div>
	);
};

export default CreatedBy;
