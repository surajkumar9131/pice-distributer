import { useState, useEffect } from "react";
import Input from "./Input";
import wpShare from "../assets/wpshare.svg";
import { useNavigate } from "react-router-dom";
import { addBody, request, getUrl } from "../utils/networkUtils";
import { useMutation } from "react-query";
import { TOKEN_TYPE } from "../utils/constants";
import ErrrorText from "./ErrrorText";

const docType = [
	{
		id: "1",
		title: "Distributor",
	},
	{
		id: "2",
		title: "Manufacturer",
	},
	{
		id: "3",
		title: "Wholesaler",
	},
	{
		id: "4",
		title: "Service Provider ",
	},
	{
		id: "5",
		title: "Other",
	},
];

// eslint-disable-next-line react/prop-types
const DetailsForm = ({ showTag, gstNo }) => {
	const navigate = useNavigate();
	const [selectedTag, setSelectedTag] = useState(0);
	const [type, setType] = useState(docType[0].title);
	const [gst, setGst] = useState("");
	const [mobile, setMobile] = useState("");
	const [vaildGst, setVaildGst] = useState(false);
	const [validPhone, setValidPhone] = useState(false);
	const [error, setError] = useState(null);
	const pattern = new RegExp(/^\d{1,10}$/);
	useEffect(() => {
		if (gstNo) {
			setGst(gstNo);
		}
	}, [gstNo]);

	const signin = (data) => {
		const url = getUrl(`iam/signin`);
		return request("POST", url, addBody(data), false);
	};

	const { mutate, isLoading: signinLoading } = useMutation(signin, {
		mutationKey: "distributor/signin",
		onSuccess: (res) => {
			if (res.status === 204 || res.status === 200) {
				let response = JSON.parse(res.data);
				localStorage.setItem(TOKEN_TYPE, response?.data?.session?.id);
				navigate("/offer", { state: response?.data });
			}
		},
		onError: (err) => {
			if (err.response.status === 400) {
				const error = JSON.parse(err.response.data);
				setError(error?.meta?.message);
				console.log(error);
			} else {
				setError("Something Went Wrong");
			}
			console.log(err);
		},
	});

	const validateGst = (gst) => {
		var re = /^\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}$/;
		return re.test(gst);
	};

	const validatePhone = (phone) => {
		var re = /^[9|8|7|6]\d{9}$/;
		return re.test(phone);
	};

	const onSelectTag = async (doc, index) => {
		setSelectedTag(index);
		setType(doc.title);
	};

	const extendLineHandler = () => {
		if (!validateGst(gst)) {
			setVaildGst(true);
		} else if (!validatePhone(mobile)) {
			setValidPhone(true);
		}
		if (validateGst(gst) && validatePhone(mobile)) {
			mutate({
				gst,
				mobile,
				type,
			});
		}
	};

	const chatOnWp = () => {
		window.location.href = "https://wa.me/918123475591?";
	};

	return (
		<div>
			<div className="bg-white rounded-3xl px-9 pt-12 pb-8">
				<div className="text-2xl font-medium">Enter details</div>
				<div className="pt-8">
					<div className="font-normal text-sm mb-2">I am</div>
					<div className="flex gap-3 flex-wrap">
						{docType &&
							docType.map((item, index) => (
								<div
									key={index}
									className={selectedTag === index ? "active-tag" : "tag"}
									onClick={() => onSelectTag(item, index)}
								>
									<div>{item.title}</div>
								</div>
							))}
					</div>
					<div className="my-6">
						<Input
							label={"My Company GST *"}
							placeholder={"Enter Company GST "}
							required={true}
							value={gst}
							onChange={(e) => {
								if (validateGst(e.target.value.toUpperCase())) {
									setVaildGst(false);
								}
								setGst(e.target.value.toUpperCase());
							}}
							error={vaildGst}
							errorText={"Please Enter Valid GST Number"}
						/>
					</div>
					<div className="mt-6 mb-8 relative">
						<span className="absolute top-[44px] lg:top-[46px] left-4">
							+91
						</span>
						<Input
							label={"My Mobile Number*"}
							placeholder={"Enter Mobile Number "}
							required={true}
							value={mobile}
							type={"tel"}
							pattern="[1-9]{1}[0-9]{9}"
							maxlength={10}
							onChange={(e) => {
								if (
									validatePhone(e.target.value) &&
									pattern.test(e.target.value)
								) {
									setValidPhone(false);
								}
								setMobile(e.target.value);
							}}
							errorText={"Please Enter Valid Mobile Number"}
							error={validPhone}
						/>
					</div>
					<button
						className={`${
							gst.length >= 10 && mobile.length === 10
								? "btn-primary"
								: "btn-dissabled"
						}  btn-primary`}
						onClick={extendLineHandler}
					>
						<div className="flex items-center gap-1 justify-center">
							{signinLoading && <div className="loader"></div>}
							Extend Credit Line
						</div>
					</button>
					{error && <ErrrorText text={error} />}
				</div>
			</div>
			{!showTag && (
				<div className="hidden lg:block bg-[#D3E1FF] rounded-3xl px-6 py-4 mt-5 flex-between ">
					<div className="text-[#4B6CB4] text-sm font-normal">
						<p>Are you a CA/Accountant ? </p>
						<p>Earn upto ₹50,000</p>
					</div>
					<div onClick={chatOnWp} className="cursor-pointer">
						<img src={wpShare} />
					</div>
				</div>
			)}
		</div>
	);
};

export default DetailsForm;
