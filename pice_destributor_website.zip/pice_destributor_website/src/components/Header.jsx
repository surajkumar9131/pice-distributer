import Logo from "../assets/pice.svg";
import Gst from "../assets/gst.svg";
import { useNavigate } from "react-router-dom";

const Header = () => {
	const navigate = useNavigate();

	return (
		<div className="bg-primary-100 w-full px-6 lg:px-32 py-4 flex-between fixed z-50">
			<div
				className="cursor-pointer"
				onClick={() => {
					navigate("/");
				}}
			>
				<img src={Logo} alt="logo" />
			</div>
			<div className="block lg:hidden">
				<div className="flex items-center gap-1 justify-center text-white text-xl">
					<img src={Gst} alt="gst" />
					GST Safe
				</div>
			</div>
		</div>
	);
};

export default Header;
