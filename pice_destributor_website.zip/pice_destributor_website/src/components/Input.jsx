/* eslint-disable react/prop-types */
const Input = ({
	label,
	value = "",
	placeholder,
	disabled,
	onChange,
	required,
	error,
	errorText,
	type = "text",
	pattern,
	maxlength,
}) => {
	return (
		<div>
			<div className="font-normal text-sm mb-2" htmlFor={label}>
				{label}
			</div>
			<input
				placeholder={placeholder}
				onChange={onChange}
				disabled={disabled}
				value={value}
				type={type}
				pattern={pattern}
				required={required}
				maxLength={maxlength}
				className={`input-box ${error ? "input-error" : ""} ${
					type === "tel" ? "tel-input" : ""
				}`}
			/>
			{error && <p className="text-red-600 text-sm">{errorText}</p>}
		</div>
	);
};

export default Input;
