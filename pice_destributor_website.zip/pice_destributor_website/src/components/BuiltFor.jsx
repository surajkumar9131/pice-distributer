import Logo1 from "../assets/distribute.svg";
import Logo2 from "../assets/manufacture.svg";
import Logo3 from "../assets/wholesale.svg";

const BuiltFor = () => {
	return (
		<div className="fold my-0 lg:my-5">
			<div className="text-black-200 text-center text-xs font-normal mb-6 lg:mb-7">
				BUILT FOR
			</div>
			<div className="flex flex-col lg:flex-row justify-between bg-primary-900 px-20 py-8 lg:py-10 rounded-3xl">
				<div className="flex flex-col items-center mb-6 lg:mb-0">
					<img src={Logo1} alt="cert" />
					<div className="font-normal text-xl lg:text-3xl">Distributor</div>
				</div>
				<div className="flex flex-col items-center mb-6 lg:mb-0">
					<img src={Logo2} alt="cert" />
					<div className="font-normal text-xl lg:text-3xl">Manufacturer</div>
				</div>
				<div className="flex flex-col items-center">
					<img src={Logo3} alt="cert" />
					<div className="font-normal text-xl lg:text-3xl">Wholesaler</div>
				</div>
			</div>
		</div>
	);
};

export default BuiltFor;
