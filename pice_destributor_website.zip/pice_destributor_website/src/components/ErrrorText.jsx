const ErrrorText = ({ text = "Something Went wrong" }) => {
	return <div className="text-error-100 text-sm mt-3 text-center">{text}</div>;
};

export default ErrrorText;
