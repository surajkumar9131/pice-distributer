import Phone from "../assets/phone.svg";

const FirstFold = () => {
	return (
		<div>
			<div>
				<div className="z-100">
					<div className="text-3xl font-normal text-[#0265D4] mt-20">
						Grow your Business
					</div>
					<div className="text-4xl font-normal my-2">
						Extend Credit line to your
					</div>
					<div className="text-4xl font-normal my-2">Customers upto</div>
					<div className="text-5xl font-semibold my-4 text-transparent bg-clip-text bg-gradient-to-b from-[#0344AF] from-0% to-[#007CEF] to-100%">
						₹1 Cr at Zero Cost
					</div>
				</div>
				<div className="">
					<img src={Phone} />
				</div>
			</div>
			<div></div>
		</div>
	);
};

export default FirstFold;
