import Business from "../assets/business.svg";
import Trust from "../assets/trust.svg";
import Logo from "../assets/pice.svg";

const Footer = () => {
	return (
		<div className="bg-primary-100 w-full px-8 lg:px-32 py-8">
			<div className="flex-between">
				<div>
					<img src={Logo} alt="logo" />
				</div>
				<div>
					<img src={Trust} alt="logo" />
					<img src={Business} alt="logo" />
				</div>
			</div>
			<div className="mt-6 text-white">
				<div className="text-[10px] font-light text-center">
					Terms & Conditions Apply
				</div>
				<div className="thin-line"></div>
				<div className="text-[10px] font-light text-center">
					©2023 Nanosecond Technologies Private Limited
				</div>
			</div>
		</div>
	);
};

export default Footer;
