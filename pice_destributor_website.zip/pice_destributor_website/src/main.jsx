import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { RouterProvider } from "react-router-dom";
import {
	Route,
	createBrowserRouter,
	createRoutesFromElements,
} from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import SecureOfferCard from "./pages/SecureOfferCard";
import LinkGst from "./pages/LinkGst";
import SuccessCard from "./pages/SuccessCard";
import { QueryClient, QueryClientProvider } from "react-query";

const router = createBrowserRouter(
	createRoutesFromElements(
		<>
			<Route path="/" element={<Layout />}>
				<Route path="" element={<Home />} />
				<Route path="offer" element={<SecureOfferCard />} />
				<Route path="link-gst" element={<LinkGst />} />
				<Route path="success" element={<SuccessCard />} />
			</Route>
		</>
	)
);
const queryClient = new QueryClient();
ReactDOM.createRoot(document.getElementById("root")).render(
	<React.StrictMode>
		<QueryClientProvider client={queryClient}>
			<RouterProvider router={router} />
		</QueryClientProvider>
	</React.StrictMode>
);
